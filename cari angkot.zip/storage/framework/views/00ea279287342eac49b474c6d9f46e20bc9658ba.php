<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">SEWA ANGKOT</div>

                <div class="card-body">
                    <!-- <div class="form-group row mb-0">
                    <a href="<?php echo e(route('Juragan')); ?>" class="btn btn-default"> Sewa Angkot </a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <center>
                    <h3>Ini Daftar Juragan dan Angkotnya!</h3>
                    </center>
                    <br>
                    <p><justify>Anda ingin sewa angkot? Tinggal hubungi saja juragannya dan Anda juga dapat bernegosiasi dengan juragannya, loh! Jadi, gak perlu khawatir kalau supir angkot nembak harga dengan harga yang terlalu mahal.<justify></p>
                    <center>
                    <table border="6" class="center">
                    <tr>
        <td><b><center>No.</center></b></td>
        <td><b><center>Nama Juragan</center></b></td>
        <td><b><center>Nomor Telepon</center></b></td>
        <td><b><center>Nomor Angkot</center></b></td>
    </tr>
    <tr>
        <td><b><center>1.</center></b></td>
        <td><center>Muhammad Zaenal</center></td>
        <td><center>08223458766</center></td>
        <td><center>02</center></td>
    </tr>
    <tr>
        <td><b><center>2.</center></b></td>
        <td><center>Ahmad Saefuddin</center></td>
        <td><center>087896700324</center></td>
        <td><center>02</center></td>
    </tr>
    <tr>
        <td><b><center>3.</center></b></td>
        <td><center>Arnold</center></td>
        <td><center>08130896421</center></td>
        <td><center>02</center></td>
    </tr>
    <tr>
        <td><b><center>4.</center></b></td>
        <td><center>Nurdin Abidin</center></td>
        <td><center>08573142667</center></td>
        <td><center>03</center></td>
    </tr>
    <tr>
        <td><b><center>5.</center></b></td>
        <td><center>Abdullah Rosyad</center></td>
        <td><center>085789802451</center></td>
        <td><center>03</center></td>
    </tr>
    <tr>
        <td><b><center>6.</center></b></td>
        <td><center>Syarifuddin</center></td>
        <td><center>081310672430</center></td>
        <td><center>03</center></td>
    </tr>
    <tr>
        <td><b><center>7.</center></b></td>
        <td><center>Rachmad Tri Putra</center></td>
        <td><center>087879241538</center></td>
        <td><center>03</center></td>
    </tr>
    <tr>
        <td><b><center>8.</center></b></td>
        <td><center>Komardiansyah</center></td>
        <td><center>0214907683</center></td>
        <td><center>06</center></td>
    </tr>
    <tr>
        <td><b><center>9.</center></b></td>
        <td><center>Rizal Abian</center></td>
        <td><center>08226153478</center></td>
        <td><center>06</center></td>
    </tr>
    <tr>
        <td><b><center>10.</center></b></td>
        <td><center>Arfa Pratama</center></td>
        <td><center>081325543874</center></td>
        <td><center>06</center></td>
    </tr>
                    </table>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cari_angkot\resources\views/Juragan.blade.php ENDPATH**/ ?>