<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">MENU ANGKOT</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <center><h3>Selamat, Anda Berhasil Daftar!<h3><center>
                    <br>
                    <h5>Silakan Anda Pilih Menu di Bawah Ini : <h5>

                    <div class="links">
                    <a href="<?php echo e(route ('Jalanan')); ?>" class="btn btn-default">Rute Angkot</a>
                    <a href="<?php echo e(route ('Juragan')); ?>" class="btn btn-default">Sewa Angkot</a>
                    <a href="<?php echo e(route ('Fun')); ?>" class="btn btn-default">Fakta Menarik Angkot</a>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cari_angkot\resources\views/home.blade.php ENDPATH**/ ?>