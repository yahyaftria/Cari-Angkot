<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">FAKTA MENARIK</div>

                <div class="card-body">
                    <!-- <div class="form-group row mb-0">
                    <a href="<?php echo e(route('Juragan')); ?>" class="btn btn-default"> Sewa Angkot </a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <center>
                    <h3>Inilah Fakta Menarik Tentang Angkot!</h3>
                    </center>
                    <br>
                    Tau nggak, sih? Angkot punya fakta menarik, Loh!
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cari_angkot\resources\views/Fun.blade.php ENDPATH**/ ?>