<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">RUTE ANGKOT</div>
                    
                <div class="card-body">
                    <!-- <div class="form-group row mb-0">
                    <a href="<?php echo e(route('Juragan')); ?>" class="btn btn-default"> Sewa Angkot </a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    
                    <center><h3>Ini Rute Angkotnya!</h3></center><br>
                    <p>Kalo bingung mau ke suatu tujuan tapi gak tau harus naik angkot yang mana, yuk liat disini! Dijamin nggak nyasar lagi, deh!</p><br>
                    <p><b>RUTE ANGKOT 01 (Cipinang Gading - Cipaku - Merdeka)</b></p>
                    <center><img src="img/rute_01.png" /><br><br></center>
                    <p><justify><b>RUTE :</b> Terminal Merdeka - Jl. Perintis Kemerdekaan - Jl. Mawar - Jl. Merdeka - Jl. MA. Salmun - Jl. Mayor Oking - Stasiun Bogor - Jl. Kapten Muslihat - SSA (Exit Pasar Bogor) - Jl. Suryakencana - Jl. Siliwangi - Jl. Lawang Gintung - Jl. Cipaku - Stasiun Batutulis - Jl. Saleh Danasasmita - Jl. RE. Soemantadiredja - Jl. Cipinang Gading<justify></p><br>
                    <p><b>RUTE ANGKOT 02 (Sukasari - Laladon)</b></p>
                    <center><img src="img/rute_02.png" /><br><br></center>
                    <p><justify><b>RUTE :</b> Terminal Laladon - Jl. Letjend. Ibrahim Adjie - Jl. MayJend. Ishak Djuarsa (Gunungbatu - Loji) - Jl. Veteran - Panaragan - Jl. Perintis Kemerdekaan - PGB Merdeka - Jl. Merdeka - Jl. Kapten Muslihat (Jembatan Merah - Stasiun Bogor) - SSA (Exit Pasar Bogor) - Jl. Suryakencana - Jl. Siliwangi (Sukasari)<justify></p><br>
                    <p><b>RUTE ANGKOT 03 (Terminal Baranangsiang - Terminal Bubulak)</b></p>
                    <center><img src="img/rute_03.png" /><br><br></center>
                    <p><justify><b>RUTE : </b> Terminal Bubulak - Jl. KH. R. Abdullah Bin Nuh - Jl. Sindangbarang Pilar - Jl. LetJend. Ibrahim Adjie  - Jl. MayJend. Ishak Djuarsa (Gunungbatu - Loji) - Jl. Veteran - Panaragan - Jl. Perintis Kemerdekaan - PGB Merdeka - Jl. Merdeka - Jl. Kapten Muslihat (Jembatan Merah - Stasiun Bogor) - Jl. Ir. H. Djuanda - Jl. Salak - Jl. Pajajaran - Botani Square - Terminal Bus Baranangsiang<justify></p><br>
                    <p><b>RUTE ANGKOT 04 (Warung Nangka - Rancamaya - Ramayana)</b></p>
                    <center><img src="img/rute_04.png" /><br><br></center>
                    <p><justify><b>RUTE : </b> Pasar Bogor - BTM - Jl. Empang - Jl. Pahlawan - Jl. Batutulis - Jl. Siliwangi - Jl. Lawang Gintung - Jl. Cipaku - Stasiun KA Batutulis - Jl. Saleh Danasasmita - Jl. Raya Cipaku - Jl. Rancamaya Utama - Jl. Rancamaya<justify></p><br>
                    <p><b>RUTE ANGKOT 07C (Ciparigi - Warung Jambu - Pasar Anyar - Taman Topi)</b></p>
                    <center><img src="img/rute_07C.png" /><br><br></center>
                    <p><justify><b>RUTE : </b> Villa Bogor Indah (BTN Ciparigi) - Jl. Raya Kedung Halang - Jl. Raya Bogor - Jl. KS. Tubun - Plaza Jambu Dua Bogor - Jl. Ahmad Yani - Air Mancur - Jl. Jend. Soedirman - RS. SALAK - Jl. Pengadilan - Jl. Dewi Sartika (Pasar Anyar - Taman Topi) - Jl. Kapten Muslihat<justify></p><br>
                    <p><b>RUTE ANGKOT 08 (Warung Jambu - Indraprasta - Ramayana)</b></p>
                    <center><img src="img/rute_08.png" /><br><br></center>
                    <p><justify><b>RUTE : </b>Plaza Jambu Dua Bogor - Jl. Raya Pajajaran - Jl. Lodaya - Jl. Kumbang - Jl. Lodaya - SSA (EXIT Sempur) - Jl. Salak - Jl. Raya Pajajaran - Jl. Bangbarung Raya - Jl. Kresna Raya - Jl. Achmad Adnawijaya<justify></p><br>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cari_angkot\resources\views/Jalanan.blade.php ENDPATH**/ ?>