@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">MENU ANGKOT</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <center><h3>Selamat, Anda Berhasil Daftar!<h3><center>
                    <br>
                    <h5>Silakan Anda Pilih Menu di Bawah Ini : <h5>

                    <div class="links">
                    <a href="{{ route ('Jalanan') }}" class="btn btn-default">Rute Angkot</a>
                    <a href="{{ route ('Juragan') }}" class="btn btn-default">Sewa Angkot</a>
                    <a href="{{ route ('Fun') }}" class="btn btn-default">Fakta Menarik Angkot</a>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
