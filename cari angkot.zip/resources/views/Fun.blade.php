@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">FAKTA MENARIK</div>

                <div class="card-body">
                    <!-- <div class="form-group row mb-0">
                    <a href="{{ route('Juragan') }}" class="btn btn-default"> Sewa Angkot </a>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif -->
                    <center>
                    <h3>Inilah Fakta Menarik Tentang Angkot!</h3>
                    </center>
                    <br>
                    Tau nggak, sih? Angkot punya fakta menarik, Loh!
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
