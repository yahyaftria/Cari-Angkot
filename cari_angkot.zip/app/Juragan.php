<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Juragan extends Model
{
    //
}
