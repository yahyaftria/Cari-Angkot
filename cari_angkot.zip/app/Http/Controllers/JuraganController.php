<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JuraganController extends Controller
{
    public function index ()
    {
        return view ('Juragan');
    }
}
