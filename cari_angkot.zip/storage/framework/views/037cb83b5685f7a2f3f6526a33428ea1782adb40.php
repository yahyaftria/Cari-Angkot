<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">LAPOR</div>

                <div class="card-body">
                    <!-- <div class="form-group row mb-0">
                    <a href="<?php echo e(route('Juragan')); ?>" class="btn btn-default"> Sewa Angkot </a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <center>
                    <h3>Lapor Angkot</h3>
                    </center>
                    Ada laporan apa hari ini? Boleh komentar, saran, dan kritik
                    <br />
            <form method='post' style='font-size:12pt; height:400px; width:400px'>
            <br />
            <textarea name='comment' id='comment'></textarea><br />
            <input type='hidden' name='articleid' id='articleid' style='font-size:12pt; height:400px; width:400px' value='<? echo $_GET["id"]; ?>' />
            <input type='submit' value='Kirim' />  
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cari_angkot\resources\views/Laporan.blade.php ENDPATH**/ ?>