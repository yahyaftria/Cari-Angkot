<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">FAKTA MENARIK</div>

                <div class="card-body">
                    <!-- <div class="form-group row mb-0">
                    <a href="<?php echo e(route('Juragan')); ?>" class="btn btn-default"> Sewa Angkot </a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?> -->
                    <center>
                    <h3>Ini Fakta Menarik Tentang Angkot</h3>
                    </center>
                    <br>
                    Tau nggak, sih? Angkot punya fakta menarik, Loh!<br>
                    <p align="justify"><b>1.</b> Ada hasil survey yang dilakukan oleh Cermati di tahun 2017 mengenai transportasi umum seperti angkot</p>
                    <center><img src="img/survei_01.png" /><br><br></center>
                    <p align="justify"><b>2.</b> Menurut studi di Jepang, bepergian dengan angkutan umum lebih sehat daripada naik mobil pribadi atau berjalan (American Heart Association)</p>
                    <p align="justify"><b>3.</b> Menghemat pengeluaran uang, cuma butuh beberapa rupiah ajaloh buat naik angkot</p>
                    <p align="justify"><b>4.</b> Lebih banyak bergerak untuk berpindah-pindah angkot hehe jadi sekalian olahraga tubuh nih</p>
                    <p align="justify"><b>5.</b> Mengasah kemampuan bersosialisasi karna kita akan bertemu orang-orang barudi dalam angkot</p>
                    <p align="justify"><b>6.</b> Membantu memaksimalkan subsidi Bahan Bakar Minyak (BBM)/p>
                    <p align="justify"><b>7.</b> Sangat merakyat! Karena pengguna angkot berasal dari berbagai kalangan, mulai dari anak kecil sampai orang dewasa</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cari_angkot\resources\views/Fun.blade.php ENDPATH**/ ?>