<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSewaAngkotTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sewa_angkot', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->time('WaktuSewa');
            $table->time('WaktuKembali');
            $table->string('NoKendaraan');
            $table->integer('HargaSewa');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sewa_angkot');
    }
}
