<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJuraganAngkotTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('juragan_angkot', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('DaftarAngkot');
            $table->string('DaftarPemilikAngkot');
            $table->integer('HargSewa');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('juragan_angkot');
    }
}
