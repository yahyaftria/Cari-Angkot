<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAngkotTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('angkot', function (Blueprint $table) {
            $table->increments('id');
            $table->string('NoKendaraan');
            $table->string('NamaSupir');
            $table->string('WarnaAngkot');
            $table->string('NamaJuragan');
            $table->string('IDKendaraan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('angkot');
    }
}
